Place your images here and update image paths in index.html.
